package rough;

import base.Page;
import pages.CartPage;
import pages.HomePage;
import pages.ProductPage;

public class Prueba {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HomePage home = new HomePage();
		ProductPage product = home.selectProduct(home.PRODUCT_1);
		product.addToCart();
		CartPage cart  =Page.menu.goToCart();
		cart.placeOrder();
		cart.fillForm("jano", "chile", "santiago", "123412341234", "09", "15");
		cart.submitForm();
		cart.OK();

	}

}
