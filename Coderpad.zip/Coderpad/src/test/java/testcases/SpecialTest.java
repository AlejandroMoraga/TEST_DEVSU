package testcases;

import java.io.IOException;

import org.testng.annotations.Test;

import base.Page;
import pages.CartPage;
import pages.HomePage;
import pages.ProductPage;

public class SpecialTest extends BaseTest{
	
	@Test
	public void specialTest() throws IOException {
		HomePage home = new HomePage();
		ProductPage product = home.selectProduct(home.PRODUCT_1);
		product.addToCart();
		
		CartPage cart  =Page.menu.goToCart();
		cart.placeOrder();
		
		cart.fillForm(Page.getProperty("_name"), Page.getProperty("_country"), Page.getProperty("_city"), Page.getProperty("_card"), Page.getProperty("_month"), Page.getProperty("_year"));
		cart.submitForm();
		String[] summary=cart.getSummary();
		
		Page.verifyEquals(summary[7], Page.getProperty("_card"));
		Page.verifyEquals(summary[9], Page.getProperty("_name"));
		String thanks = cart.getThanksMessage();
		Page.verifyEquals(thanks, Page.getProperty("thanks_message"));
		Page.verifyTrue(cart.getStringSummary().contains(Page.getProperty("cart.summary.id")),"transaction summary should contain "+Page.getProperty("cart.summary.id"));
		Page.verifyTrue(cart.getStringSummary().contains(Page.getProperty("cart.summary.card")),"transaction summary should contain "+Page.getProperty("cart.summary.card"));
		Page.verifyTrue(cart.getStringSummary().contains(Page.getProperty("cart.summary.amount")),"transaction summary should contain "+Page.getProperty("cart.summary.amount"));
		Page.verifyTrue(cart.getStringSummary().contains(Page.getProperty("cart.summary.name")),"transaction summary should contain "+Page.getProperty("cart.summary.name"));
		Page.verifyTrue(cart.getStringSummary().contains(Page.getProperty("cart.summary.date")),"transaction summary should contain "+Page.getProperty("cart.summary.date"));	
		cart.OK();
	}

}
