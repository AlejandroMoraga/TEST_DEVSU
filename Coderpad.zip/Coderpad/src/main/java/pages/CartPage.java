package pages;

import org.openqa.selenium.By;

import base.Page;

public class CartPage extends Page {

	static final By PLACE_ORDER_BUTTON = By.xpath("//button[text()='Place Order']");
	static final By TOTAL = By.id("totalm");
	static final By NAME = By.id("name");
	static final By COUNTRY = By.id("country");
	static final By CITY = By.id("city");
	static final By CREDIT_CARD = By.id("card");
	static final By MONTH = By.id("month");
	static final By YEAR = By.id("year");
	static final By PURCHASE_BUTTON = By.xpath("//button[text()='Purchase']");
	static final By OK_BUTTON = By.xpath("//button[@class='confirm btn btn-lg btn-primary']");
	
	static final By THANKS_MESSAGE = By.xpath("//div[@class=\"sweet-alert  showSweetAlert visible\"]//h2");
	static final By TRANSACION_SUMMARY = By.xpath("//p[@class='lead text-muted ']");
	static final String RESUME="//p[@class='lead text-muted ']";
	
	

	public String getThanksMessage() {
		return getText(THANKS_MESSAGE,"THANKS_MESSAGE");
	}
	
	public String[]  getSummary() {
		return getStringText(TRANSACION_SUMMARY, "TRANSACION_SUMMARY");
	}
	
	public String getStringSummary() {
		return getText(TRANSACION_SUMMARY,"TRANSACION_SUMMARY");
	}
	
	public void placeOrder() {
		click(PLACE_ORDER_BUTTON,"PLACE_ORDER_BUTTON");
	}

	public void fillForm(String name, String country, String city, String card, String month, String year) {

		type(NAME, name,"NAME");
		type(COUNTRY, country,"COUNTRY");
		type(CITY, city,"CITY");
		type(CREDIT_CARD, card,"CREDIT_CARD");
		type(MONTH, month,"MONTH");
		type(YEAR, year,"YEAR");

	}

	public void submitForm() {
		click(PURCHASE_BUTTON,"PURCHASE_BUTTON");
	}

	public void OK() {
		click(OK_BUTTON,"OK_BUTTON");
	}
}
