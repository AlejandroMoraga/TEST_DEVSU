package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.Page;

public class HomePage extends Page {

	 public final By PRODUCT_1 = By.xpath("(//div[@class='card-block'])[" + 1 + "]/h4/a");
	 public final By PRODUCT_2 = By.xpath("(//div[@class='card-block'])[" + 2 + "]/h4/a");
	 public final By PRODUCT_3 = By.xpath("(//div[@class='card-block'])[" + 3 + "]/h4/a");
	 public final By PRODUCT_4 = By.xpath("(//div[@class='card-block'])[" + 4 + "]/h4/a");
	 public final By PRODUCT_5 = By.xpath("(//div[@class='card-block'])[" + 5 + "]/h4/a");
	 public final By PRODUCT_6 = By.xpath("(//div[@class='card-block'])[" + 6 + "]/h4/a");

	public ProductPage selectProduct(By by) {

		click(by,"PRODUCTO");
		return new ProductPage();

	}

}
