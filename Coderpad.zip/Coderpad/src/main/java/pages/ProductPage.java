package pages;

import org.openqa.selenium.By;

import base.Page;

public class ProductPage extends Page {

	public final By ADD_TO_CART = By.xpath("//a[text()='Add to cart']");
	public final By PRODUCT_NAME = By.className("name");
	public final By PRODUCT_DESCRIPTION = By.id("more-information");
	public final By PRODUCT_PRICE = By.className("price-container");

	public void addToCart() {
		click(ADD_TO_CART,"ADD_TO_CART");
	}

}
