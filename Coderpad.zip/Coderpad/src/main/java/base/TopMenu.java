package base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pages.CartPage;
import pages.HomePage;

public class TopMenu {

	WebDriver driver;

	public TopMenu(WebDriver driver) {
		this.driver = driver;
	}

	private final By HOME = By.xpath("//a[text()='Home ']");
	private final By CONTACT = By.xpath("//a[text()='Contact']");
	private final By ABOUTUS = By.xpath("//a[text()='About us']");
	private final By CART = By.xpath("//a[text()='Cart']");
	private final By LOGIN = By.xpath("//a[text()='Login']");
	private final By SIGNUP = By.xpath("//a[text()='Sign up']");

	public HomePage goToHome() {
		driver.findElement(HOME).click();
		return new HomePage();

	}

	public void gotToContact() {
		driver.findElement(CONTACT).click();
	}

	public void goToAboutUs() {
		driver.findElement(ABOUTUS).click();
	}

	public CartPage goToCart() {
		driver.findElement(CART).click();
		return new CartPage();
	}

	public void goToLogin() {
		driver.findElement(LOGIN).click();
	}

	public void goToSignUp() {
		driver.findElement(SIGNUP).click();
	}

}
